using Il2CppSG.Airlock;
using Il2CppSG.Airlock.Network;

namespace AU3DUnlimited
{
    static class PlayerChecks
    {
        public static bool IsLive(PlayerState state) => state != null && state.Object != null && state.Object.IsValid;

        public static bool IsConnected(PlayerState state) => IsLive(state) && state.IsConnected;
    }
}
