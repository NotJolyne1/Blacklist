using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HarmonyLib;
using Il2CppFusion;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Il2CppSG.Airlock;
using Il2CppSG.Airlock.Customization;
using Il2CppSG.Airlock.Network;
using Il2CppSG.Airlock.UI.TitleScreen;
using MelonLoader;
using UnityEngine;
using ModerationScreen = Il2CppSG.Airlock.UI.Moderation.Moderation;
using ModerationTab = Il2CppSG.Airlock.UI.Moderation.ModerationPlayerTab;
using LobbyScreen = Il2CppSG.Airlock.UI.UILobbyScreenUI;
using NameTags = Il2CppSG.Airlock.UI.UINameTagsDrawer;
using QuickChat = Il2CppSG.Airlock.UI.QuickChatDrawer;
using VotingBoard = Il2CppSG.Airlock.UI.VotingMainUI;
using VotingPanel = Il2CppSG.Airlock.UI.VotingPlayerUI;
using VrRig = Il2CppSG.Airlock.XR.XRRig;

namespace AU3DUnlimited
{
    static class Dev
    {
        public static string Role = "";
        public static string Name = "";

        static bool started;
        static bool inLobby;

        static string CodeFile => DataFile("devroom.txt");

        static string DataFile(string fileName) => Path.Combine(MelonLoader.Utils.MelonEnvironment.UserDataDirectory, fileName);

        [System.Runtime.CompilerServices.ModuleInitializer]
        public static void Init()
        {
            MelonEvents.OnSceneWasInitialized.Subscribe((buildIndex, scene) => OnScene());
            var arguments = System.Environment.GetCommandLineArgs();
            for (int index = 0; index < arguments.Length - 1; index++)
            {
                if (arguments[index] == "-room") Role = arguments[index + 1];
                if (arguments[index] == "-tag") Name = arguments[index + 1];
            }
            string roleFile = DataFile("devrole.txt");
            if (Role == "" && File.Exists(roleFile)) Role = File.ReadAllText(roleFile).Trim();
            if (Name == "") Name = Role;
            if (Role != "") MelonLogger.Msg($"Dev role is {Role}, named {Name}");
        }

        public static void OnScene()
        {
            if (Role == "" || started || Object.FindObjectOfType<HostGameMenu>(true) == null) return;
            started = true;
            MelonCoroutines.Start(Begin());
        }

        static IEnumerator Begin()
        {
            float delay = Role == "join" ? 30 : 12;
            yield return new WaitForSeconds(delay);
            Mod.Enabled = true;
            if (Role == "join") ShowJoinMenu();
            if (Role != "join") ShowHostMenu();
            MelonLogger.Msg($"Dev {Role} started");
        }

        static void ShowHostMenu()
        {
            if (File.Exists(CodeFile)) File.Delete(CodeFile);
            Object.FindObjectOfType<HostGameMenu>(true).gameObject.SetActive(true);
        }

        static void ShowJoinMenu() => Object.FindObjectOfType<DirectJoinMenu>(true).gameObject.SetActive(true);

        public static void SaveCode(string code)
        {
            if (Role != "join" && !string.IsNullOrEmpty(code)) File.WriteAllText(CodeFile, code);
        }

        public static string Code() => File.Exists(CodeFile) ? File.ReadAllText(CodeFile).Trim() : "";

        public static void OnLobby(SpawnManager spawnManager)
        {
            if (Role == "" || inLobby) return;
            inLobby = true;
            MelonCoroutines.Start(Check(spawnManager));
        }

        static IEnumerator Check(SpawnManager spawnManager)
        {
            yield return new WaitForSeconds(20);
            Report(spawnManager, "start");
            LogColors();
            ShowSlotName();
            LogModeration();
            LogBodies(spawnManager);
            LogMinigamePlayers();
            LogLimits(spawnManager);
            if (Role == "join") yield return CopyHostColor(spawnManager);
            yield return new WaitForSeconds(10);
            Report(spawnManager, "after");
            Shot("lobby");
            DumpUI();
            yield return TryModeration("lobby");
            if (Role == "match") yield return RunMatch(spawnManager);
            while (true)
            {
                yield return new WaitForSeconds(30);
                Report(spawnManager, "tick");
            }
        }

        static void LogColors()
        {
            var customization = Object.FindObjectOfType<CustomizationManager>();
            var elements = customization._elementCollection.AllCustomizationElements;
            int colors = 0;
            int entitled = 0;
            int locked = 0;
            for (int index = 0; index < elements.Count; index++)
            {
                if (elements[index].Type != CustomizationElement.CosmeticType.Color) continue;
                colors++;
                if (customization.IsEntitled(index)) entitled++;
                if (elements[index].IsLocked) locked++;
            }
            MelonLogger.Msg($"Colors: {colors} total, {entitled} entitled, {locked} locked");
        }

        static void ShowSlotName()
        {
            var quickChat = Object.FindObjectOfType<QuickChat>(true);
            if (quickChat != null) quickChat.UpdateSingleName(15, "slot15");
        }

        static void LogModeration()
        {
            foreach (var screen in Object.FindObjectsOfType<ModerationScreen>(true))
            {
                var tabs = screen._moderationPlayers;
                var parent = tabs.Length > 0 ? tabs[0].transform.parent : null;
                string components = ComponentNames(parent);
                string tabSummaries = string.Join(" ", tabs.Select(tab => TabSummary(tab)));
                MelonLogger.Msg($"Moderation {screen.name}: {tabs.Length} tabs, parent {parent?.name} [{components}] {tabSummaries}");
            }
        }

        static string TabSummary(ModerationTab tab)
        {
            var position = tab.transform.localPosition;
            return $"{tab._playerId}@{position.x:0.##},{position.y:0.##}";
        }

        static string ComponentNames(Transform transform)
        {
            if (transform == null) return "";
            return string.Join(",", transform.GetComponents<Component>().Select(component => component.GetIl2CppType().Name));
        }

        static void LogBodies(SpawnManager spawnManager)
        {
            for (int index = 0; index < spawnManager._networkedBodies.Count; index++)
            {
                var body = spawnManager._networkedBodies[index];
                MelonLogger.Msg($"Body {index}: {body?.name}, player ref {body?._PlayerRefIndex}");
            }
        }

        static void LogMinigamePlayers()
        {
            foreach (var minigamePlayer in Object.FindObjectsOfType<MinigamePlayer>(true))
            {
                var state = minigamePlayer.PState;
                MelonLogger.Msg($"Minigame player {minigamePlayer.name}: id {minigamePlayer.PlayerID}, state {state?._playerId}");
            }
        }

        static void LogLimits(SpawnManager spawnManager)
        {
            var snapshot = spawnManager.PlayerSnapshot;
            var rig = Object.FindObjectOfType<VrRig>();
            var quickChat = Object.FindObjectOfType<QuickChat>(true);
            var lobby = Object.FindObjectOfType<LobbyScreen>(true);
            bool selfie15 = snapshot.GetSelfieTexture(15) == snapshot._textures[15];
            bool material15 = snapshot.GetSelfieMaterial(15) == snapshot._materials[15];
            bool selfie19 = snapshot.GetSelfieTexture(19) == snapshot._textures[19];
            MelonLogger.Msg($"Slot checks: selfie 15 {selfie15}, material 15 {material15}, selfie 19 {selfie19}");
            MelonLogger.Msg($"Minimap indicators: {rig?.MinimapVR?.PlayerIndicators?.Count} in VR, {rig?.Minimap3D?.PlayerIndicators?.Count} in 3D");
            MelonLogger.Msg($"Quick chat name 15: {quickChat?._playerNames?[15]}, lobby max {lobby?._maxPlayers}");
            MelonLogger.Msg($"Slot 19: avatar {spawnManager._playerAvatars[19]?.name}, state {spawnManager._playerStates[19]?.name}, texture {snapshot._textures[19]?.name}");
        }

        static IEnumerator CopyHostColor(SpawnManager spawnManager)
        {
            var host = spawnManager._playerStates[Mod.Slots - 1];
            int hostColor = host.ColorId;
            var customization = Object.FindObjectOfType<CustomizationManager>();
            MelonLogger.Msg($"{Name} is asking for host color {hostColor}");
            customization.ApplyElement(hostColor);
            yield return new WaitForSeconds(8);
            var local = spawnManager.GetLocalPlayerState();
            bool same = local.ColorId == host.ColorId;
            MelonLogger.Msg($"{Name} color is now {local.ColorId}, host color is {host.ColorId}, same: {same}");
        }

        static IEnumerator RunMatch(SpawnManager spawnManager)
        {
            var gameState = Object.FindObjectOfType<GameStateManager>();
            MelonLogger.Msg("Starting match");
            gameState.StartGame();
            yield return WaitForState(gameState, GameplayStates.Task, 120);
            yield return new WaitForSeconds(3);
            MelonLogger.Msg($"Calling meeting during {gameState.GameModeStateValue.GameState}");
            Object.FindObjectOfType<VoteManager>().CallVote(true);
            yield return new WaitForSeconds(8);
            DumpUI();
            Shot("meeting0");
            yield return WaitForState(gameState, GameplayStates.Voting, 200);
            SnapPanels("discussion");
            yield return WaitForState(gameState, GameplayStates.Voting, 200);
            yield return new WaitForSeconds(40);
            SnapPanels("vote");
            yield return TryBoard();
            yield return TryModeration("vote");
            for (int round = 1; round <= 5; round++)
            {
                yield return new WaitForSeconds(15);
                Report(spawnManager, $"meeting{round}");
                Shot($"meeting{round}");
            }
            MelonLogger.Msg("Match test finished");
        }

        static IEnumerator WaitForState(GameStateManager gameState, GameplayStates target, int maxChecks)
        {
            for (int check = 0; check < maxChecks && gameState.GameModeStateValue.GameState != target; check++) yield return new WaitForSeconds(0.25f);
        }

        public static void Dump(Il2CppSystem.Object target, string label)
        {
            if (target == null) { MelonLogger.Msg($"Dump {label}: null"); return; }
            var flags = Il2CppSystem.Reflection.BindingFlags.Instance | Il2CppSystem.Reflection.BindingFlags.Public | Il2CppSystem.Reflection.BindingFlags.NonPublic;
            var builder = new System.Text.StringBuilder();
            foreach (var field in target.GetIl2CppType().GetFields(flags))
            {
                string text;
                try { text = Describe(field, field.GetValue(target)); }
                catch { text = "?"; }
                builder.Append($" {field.Name}={text}");
            }
            MelonLogger.Msg($"Dump {label}:{builder}");
        }

        static string Describe(Il2CppSystem.Reflection.FieldInfo field, Il2CppSystem.Object value)
        {
            if (value == null) return "null";
            var fieldType = field.FieldType;
            if (fieldType.IsArray) return $"[{value.Cast<Il2CppSystem.Array>().Length}]";
            var countProperty = fieldType.GetProperty("Count");
            if (fieldType.IsGenericType && countProperty != null) return $"({countProperty.GetValue(value)})";
            var unityObject = value.TryCast<Object>();
            if (unityObject != null) return $"'{unityObject.name}'";
            return value.ToString();
        }

        public static void DumpUI()
        {
            DumpNameTags();
            DumpModerationTabs();
            DumpModerationScreens();
            DumpVotingBoards();
        }

        static void DumpNameTags()
        {
            foreach (var drawer in Object.FindObjectsOfType<NameTags>(true))
            {
                Dump(drawer, $"nametags {drawer.name}");
                for (int index = 0; index < drawer._playerNames.Length; index++)
                {
                    var tag = drawer._playerNames[index];
                    MelonLogger.Msg($"Name {index}: '{tag?.text}', names[{index}] '{drawer._names[index]}', object {tag?.name}, position {tag?.transform.localPosition}, id {drawer._nameIDProps[index]}");
                }
                Dump(drawer._baker, "baker");
            }
        }

        static void DumpModerationTabs()
        {
            foreach (var tab in Resources.FindObjectsOfTypeAll<ModerationTab>())
            {
                if (!tab.gameObject.scene.IsValid()) continue;
                var parent = tab.transform.parent;
                MelonLogger.Msg($"Mod tab {tab.name}: id {tab._playerId}, active {tab.gameObject.activeSelf}/{tab.gameObject.activeInHierarchy}, parent {parent?.name} ({parent?.childCount} kids), grandparent {parent?.parent?.name}, position {tab.transform.localPosition}, components [{ComponentNames(parent)}]");
            }
        }

        static void DumpModerationScreens()
        {
            foreach (var screen in Resources.FindObjectsOfTypeAll<ModerationScreen>())
            {
                if (!screen.gameObject.scene.IsValid()) continue;
                MelonLogger.Msg($"Moderation {screen.name}: {screen._moderationPlayers?.Length} tabs, active {screen.gameObject.activeInHierarchy}, path {screen.transform.parent?.name}/{screen.name}");
            }
        }

        static void DumpVotingBoards()
        {
            foreach (var board in Object.FindObjectsOfType<VotingBoard>(true))
            {
                Dump(board, $"votingmain {board.name} active {board.gameObject.activeInHierarchy}");
                Dump(board._playerLayout, "playerLayout");
                var layoutTransform = board._playerLayout.transform;
                for (int child = 0; child < layoutTransform.childCount; child++)
                {
                    var panelTransform = layoutTransform.GetChild(child);
                    var panel = panelTransform.GetComponent<VotingPanel>();
                    MelonLogger.Msg($"Board {child}: {panelTransform.name}, active {panelTransform.gameObject.activeSelf}, position {panelTransform.localPosition}, player {panel?._playerId}");
                }
                MelonLogger.Msg($"Board map has {board._playerIdToInstance?.Count} entries");
                var pool = board._votingPlayersPool;
                if (pool == null) continue;
                if (pool.Length > 0) Dump(pool[0], "votingplayer0");
                for (int index = 0; index < pool.Length; index++)
                {
                    var entry = pool[index];
                    MelonLogger.Msg($"Pool {index}: {entry?.name}, parent {entry?.transform.parent?.name}, active {entry?.gameObject.activeSelf}, position {entry?.transform.localPosition}");
                }
            }
        }

        static Bounds BoundsOf(Transform transform)
        {
            var renderers = transform.GetComponentsInChildren<Renderer>();
            var bounds = renderers.Length > 0 ? renderers[0].bounds : new Bounds(transform.position, Vector3.one);
            foreach (var renderer in renderers) bounds.Encapsulate(renderer.bounds);
            return bounds;
        }

        static void SnapArea(Transform root, Transform facing, string what) => Capture(BoundsOf(root), facing, what, 1.05f, 5f, 20f, 1024, -1);

        public static void Snap(Renderer renderer, string what) => Capture(renderer.bounds, renderer.transform, what, 1.1f, 2f, 10f, 512, 1 << renderer.gameObject.layer);

        static void Capture(Bounds bounds, Transform facing, string what, float margin, float distance, float farClip, int size, int cullingMask)
        {
            var cameraObject = new GameObject("devcam");
            var camera = cameraObject.AddComponent<Camera>();
            camera.orthographic = true;
            camera.orthographicSize = Mathf.Max(bounds.extents.x, bounds.extents.y, bounds.extents.z) * margin;
            camera.nearClipPlane = 0.01f;
            camera.farClipPlane = farClip;
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = Color.magenta;
            camera.cullingMask = cullingMask;
            var target = new RenderTexture(size, size, 24);
            camera.targetTexture = target;
            var picture = new Texture2D(size * 2, size);
            for (int side = 0; side < 2; side++)
            {
                var direction = side == 0 ? facing.forward : -facing.forward;
                cameraObject.transform.position = bounds.center - direction * distance;
                cameraObject.transform.rotation = Quaternion.LookRotation(direction, facing.up);
                camera.Render();
                RenderTexture.active = target;
                picture.ReadPixels(new Rect(0, 0, size, size), side * size, 0);
            }
            RenderTexture.active = null;
            picture.Apply();
            File.WriteAllBytes(DataFile($"dev_{Name}_{what}.png"), ImageConversion.EncodeToPNG(picture));
            camera.targetTexture = null;
            Object.Destroy(cameraObject);
            target.Release();
        }

        static IEnumerator TryBoard()
        {
            foreach (var board in Object.FindObjectsOfType<VotingBoard>())
            {
                var layout = board._playerLayout;
                if (layout == null || !layout.gameObject.activeInHierarchy || layout.transform.childCount == 0) continue;
                var panel = layout.transform.GetChild(0).gameObject;
                MelonLogger.Msg($"Layout {board.name}: width {layout.ChildWidth}, height {layout.ChildHeight}, padding {layout.Padding}, vertical padding {layout.VertPadding}, max grid {layout.MaxGridSize}, direction {layout.DirectionOption}, option {layout.LayoutOption}, scale {panel.transform.localScale}");
                var root = board._votingUI != null ? board._votingUI.transform : board.transform;
                SnapArea(root, panel.transform, $"board1_{board.name}");
                var clones = new List<GameObject>();
                for (int copy = 1; copy < 20; copy++) clones.Add(Object.Instantiate(panel, layout.transform));
                layout.Layout();
                yield return null;
                SnapArea(root, panel.transform, $"board20_{board.name}");
                foreach (var clone in clones) Object.Destroy(clone);
                yield return null;
                layout.Layout();
            }
        }

        public static IEnumerator TryModeration(string label)
        {
            foreach (var screen in Resources.FindObjectsOfTypeAll<ModerationScreen>())
            {
                if (screen.gameObject.scene.IsValid()) ActivateWithParents(screen.transform);
            }
            yield return new WaitForSeconds(2f);
            foreach (var screen in Resources.FindObjectsOfTypeAll<ModerationScreen>())
            {
                if (!screen.gameObject.scene.IsValid() || !screen.gameObject.activeInHierarchy) continue;
                LogOpenModeration(screen, label);
            }
        }

        static void ActivateWithParents(Transform transform)
        {
            for (var current = transform; current != null; current = current.parent) current.gameObject.SetActive(true);
        }

        static void LogOpenModeration(ModerationScreen screen, string label)
        {
            var firstTab = screen.transform.GetChild(0);
            var tabBounds = BoundsOf(firstTab);
            var panelBounds = BoundsOf(screen.transform.parent);
            MelonLogger.Msg($"Moderation open {screen.transform.parent?.name}/{screen.name}: {screen._moderationPlayers?.Length} tabs, {screen.transform.childCount} kids, tab size {tabBounds.size}, panel size {panelBounds.size}, tab scale {firstTab.lossyScale}");
            for (int child = 0; child < screen.transform.childCount; child++)
            {
                var tabTransform = screen.transform.GetChild(child);
                var tab = tabTransform.GetComponent<ModerationTab>();
                MelonLogger.Msg($"  Tab {tabTransform.name}: id {tab?._playerId}, active {tabTransform.gameObject.activeSelf}, position {tabTransform.localPosition}");
            }
            SnapArea(screen.transform.parent, firstTab, $"mod{label}_{screen.GetInstanceID()}");
        }

        static void SnapPanels(string when)
        {
            int shown = 0;
            foreach (var panel in Object.FindObjectsOfType<VotingPanel>())
            {
                if (!panel.gameObject.activeInHierarchy || panel.transform.parent.name.StartsWith("PlayerPanelPool")) continue;
                var block = new MaterialPropertyBlock();
                panel._referenceRenderer.GetPropertyBlock(block);
                float atlas = block.GetFloat("_AtlasID");
                MelonLogger.Msg($"{when} panel {shown} under {panel.transform.parent.name}, player {panel._playerId.PlayerId}, atlas {atlas}");
                Snap(panel._referenceRenderer, $"{when}{shown}");
                shown++;
            }
        }

        static void Shot(string what) => ScreenCapture.CaptureScreenshot(DataFile($"dev_{Name}_{what}.png"));

        static void Report(SpawnManager spawnManager, string when)
        {
            var local = spawnManager.GetLocalPlayerState();
            if (local == null) { MelonLogger.Msg($"{Name} {when}: no local player"); return; }
            int playerId = local._playerId;
            var avatar = playerId < spawnManager._playerAvatars.Count ? spawnManager._playerAvatars[playerId] : null;
            int linked = avatar?._playerState?._playerId ?? -2;
            int connected = 0;
            foreach (var state in spawnManager._playerStates)
            {
                if (PlayerChecks.IsConnected(state)) connected++;
            }
            var lobbyScreen = Object.FindObjectOfType<LobbyScreen>();
            var buttonColliders = lobbyScreen?._initialLobbyScreenButtons ?? new Il2CppReferenceArray<Collider>(0);
            int buttons = 0;
            foreach (var collider in buttonColliders)
            {
                if (collider != null && collider.enabled && collider.gameObject.activeInHierarchy) buttons++;
            }
            MelonLogger.Msg($"{Name} {when}: id {playerId}, avatar linked to {linked}, color {local.ColorId}, spectating {local.IsSpectating}, connected {connected}, lobby buttons {buttons}");
        }

        public static int TextureIndex(PlayerSnapshot snapshot, Texture texture)
        {
            int found = -1;
            for (int index = 0; index < snapshot._textures.Count; index++)
            {
                if (snapshot._textures[index] == texture) found = index;
            }
            return found;
        }
    }

    [HarmonyPatch(typeof(GameStateManager), nameof(GameStateManager.CheckLivingPlayers))]
    class DevNoEnd
    {
        static bool Prefix(ref bool __result)
        {
            if (Dev.Role != "match") return true;
            __result = false;
            return false;
        }
    }

    [HarmonyPatch(typeof(NetworkRunner), nameof(NetworkRunner.StartGame))]
    class DevSaveCode
    {
        static void Prefix(StartGameArgs args)
        {
            if (args.GameMode == GameMode.Host) Dev.SaveCode(args.SessionName);
        }
    }

    [HarmonyPatch(typeof(AirlockPeer), nameof(AirlockPeer.DirectJoinFindGame))]
    class DevJoinCode
    {
        static void Prefix(ref string pGameName)
        {
            if (Dev.Role != "join") return;
            pGameName = Dev.Code();
            MelonLogger.Msg($"Joining {pGameName}");
        }
    }

    [HarmonyPatch(typeof(SpawnManager), nameof(SpawnManager.OnPlayerJoined))]
    class DevLobby
    {
        static void Postfix(SpawnManager __instance) => Dev.OnLobby(__instance);
    }

    [HarmonyPatch(typeof(ScreenSpaceHUD), nameof(ScreenSpaceHUD.SetSelfPortrait))]
    class DevPortrait
    {
        [HarmonyPriority(Priority.Last)]
        static void Prefix([HarmonyArgument("t")] Texture portrait)
        {
            var spawnManager = Object.FindObjectOfType<SpawnManager>();
            var snapshot = spawnManager?.PlayerSnapshot;
            int found = snapshot == null ? -1 : Dev.TextureIndex(snapshot, portrait);
            var localId = spawnManager?.GetLocalPlayerState()?._playerId;
            MelonLogger.Msg($"{Dev.Name} portrait set to texture {found}, local id {localId}");
        }
    }

    [HarmonyPatch(typeof(PlayerSnapshot), nameof(PlayerSnapshot.GetSelfieTexture))]
    class DevSelfieGet
    {
        static void Postfix(PlayerSnapshot __instance, [HarmonyArgument("id")] int selfieId, Texture __result)
        {
            int found = Dev.TextureIndex(__instance, __result);
            MelonLogger.Msg($"{Dev.Name} GetSelfieTexture({selfieId}) gave texture {found} of {__instance._textures.Count}");
        }
    }

    [HarmonyPatch(typeof(PlayerSnapshot), nameof(PlayerSnapshot.TakeSelfie))]
    class DevSelfieTake
    {
        static void Prefix([HarmonyArgument("id")] int selfieId, int color) => MelonLogger.Msg($"{Dev.Name} TakeSelfie({selfieId}, color {color})");
    }
}
