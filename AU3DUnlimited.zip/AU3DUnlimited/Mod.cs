using Il2CppSG.Airlock.UI.TitleScreen;
using MelonLoader;
using UnityEngine;

[assembly: MelonInfo(typeof(AU3DUnlimited.Mod), "AU3DUnlimited", "1.1.0", "Jolyne")]
[assembly: MelonGame("Schell Games", "Among Us 3D")]

namespace AU3DUnlimited
{
    public class Mod : MelonMod
    {
        public static MelonPreferences_Entry<string> AppId;
        public static MelonPreferences_Entry<string> Region;
        public static MelonPreferences_Entry<int> MaxPlayers;
        public static int Slots => Mathf.Clamp(MaxPlayers.Value, 10, 20);

        static bool enabled;
        static bool onTitleScreen;

        public static bool Enabled
        {
            get => enabled;
            set
            {
                enabled = value;
                Limits.Apply(value);
            }
        }

        public override void OnInitializeMelon()
        {
            var category = MelonPreferences.CreateCategory("AU3DUnlimited");
            AppId = category.CreateEntry("AppId", "", "Photon Fusion app id");
            Region = category.CreateEntry("Region", "us");
            MaxPlayers = category.CreateEntry("MaxPlayers", 20, description: "10 to 20, everyone in the room needs the mod");
            string status = string.IsNullOrEmpty(AppId.Value) ? "No AppId set" : $"Ready with {Slots} slots";
            LoggerInstance.Msg(status);
        }

        public override void OnSceneWasInitialized(int buildIndex, string sceneName)
        {
            onTitleScreen = Object.FindObjectOfType<HostGameMenu>(true) != null;
        }

        bool HasAppId()
        {
            if (!string.IsNullOrEmpty(AppId.Value)) return true;
            LoggerInstance.Error("Set AppId in UserData/MelonPreferences.cfg first");
            return false;
        }

        public override void OnGUI()
        {
            if (!onTitleScreen) return;
            bool wanted = GUI.Toggle(new Rect(10, Screen.height - 35, 160, 25), Enabled, " Unlimited Rooms");
            if (wanted == Enabled) return;
            if (wanted && !HasAppId()) return;
            Enabled = wanted;
            string state = Enabled ? "on" : "off";
            LoggerInstance.Msg($"Unlimited rooms turned {state}");
        }
    }
}
