using System;
using System.Linq;
using System.Runtime.InteropServices;
using MelonLoader;

namespace AU3DUnlimited
{
    static class Limits
    {
        [DllImport("kernel32")] static extern IntPtr GetModuleHandle(string name);
        [DllImport("kernel32")] static extern bool VirtualProtect(IntPtr address, UIntPtr size, uint protection, out uint oldProtection);

        static readonly (int offset, string pattern)[] spots =
        {
            (0x2390902, "83 FB 09"),
            (0x2390982, "83 FB 09"),
            (0x21B9E67, "83 FB 09"),
            (0x21B86E2, "83 F8 0A"),
            (0x21FE52C, "83 BB 90 00 00 00 09"),
            (0x20DF16F, "83 FB 09"),
            (0x20DF18F, "BA 0A 00 00 00"),
            (0x20A8649, "83 FF 09"),
            (0x20A866E, "BA 0A 00 00 00"),
            (0x20A02B8, "83 FB 09"),
            (0x20A02BD, "BB 09 00 00 00"),
            (0x20A06A3, "83 FB 09"),
            (0x20A06A8, "BB 09 00 00 00"),
            (0x23E1ABA, "41 83 FE 0A"),
            (0x2319757, "83 FB 0A"),
            (0x231A507, "BA 0A 00 00 00"),
            (0x2100CCD, "83 F8 0A"),
            (0x2100CF9, "C7 43 30 0A 00 00 00"),
            (0x21A0B5B, "BA 0A 00 00 00"),
            (0x21A1640, "BA 0A 00 00 00"),
            (0x2249D35, "BA 0A 00 00 00"),
            (0x21E6E27, "BA 0A 00 00 00"),
            (0x20C4626, "C7 87 BC 01 00 00 0A 00 00 00"),
            (0x2261022, "BA 0A 00 00 00"),
            (0x2261080, "BA 0A 00 00 00"),
            (0x2263FA0, "BA 0A 00 00 00"),
        };

        static IntPtr[] addresses;
        static byte[] originals;

        public static void Apply(bool enabled)
        {
            if (addresses == null && !Find()) return;
            int changed = 0;
            for (int index = 0; index < addresses.Length; index++)
            {
                if (addresses[index] == IntPtr.Zero) continue;
                byte original = originals[index];
                byte wanted = original;
                if (enabled) wanted = (byte)(original == 9 ? Mod.Slots - 1 : Mod.Slots);
                if (Marshal.ReadByte(addresses[index]) == wanted) continue;
                VirtualProtect(addresses[index], (UIntPtr)1, 0x40, out var oldProtection);
                Marshal.WriteByte(addresses[index], wanted);
                VirtualProtect(addresses[index], (UIntPtr)1, oldProtection, out _);
                changed++;
            }
            int limit = enabled ? Mod.Slots : 10;
            if (changed > 0) MelonLogger.Msg($"Changed {changed} player limits to {limit}");
        }

        static bool Find()
        {
            IntPtr game = GetModuleHandle("GameAssembly.dll");
            if (game == IntPtr.Zero) return false;
            addresses = new IntPtr[spots.Length];
            originals = new byte[spots.Length];
            int missing = 0;
            for (int index = 0; index < spots.Length; index++)
            {
                byte[] expected = spots[index].pattern.Split(' ').Select(text => Convert.ToByte(text, 16)).ToArray();
                IntPtr address = game + spots[index].offset;
                bool matches = true;
                for (int position = 0; position < expected.Length && matches; position++) matches = Marshal.ReadByte(address, position) == expected[position];
                if (!matches) { missing++; continue; }
                int limitPosition = Array.FindLastIndex(expected, value => value == 9 || value == 10);
                addresses[index] = address + limitPosition;
                originals[index] = expected[limitPosition];
            }
            if (missing > 0) MelonLogger.Warning($"{missing} player limits not found, the game was probably updated");
            return true;
        }
    }
}
