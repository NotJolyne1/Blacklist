using HarmonyLib;
using Il2CppFusion;
using Il2CppFusion.Photon.Realtime;
using Il2CppSG.Airlock.Network;
using MelonLoader;
using Task = Il2CppSystem.Threading.Tasks.Task;

namespace AU3DUnlimited
{
    [HarmonyPatch(typeof(NetworkRunner), nameof(NetworkRunner.StartGame))]
    class UseOwnApp
    {
        static void Prefix(StartGameArgs args)
        {
            if (!Mod.Enabled) return;
            var settings = PhotonAppSettings.Instance.AppSettings.GetCopy();
            settings.AppIdFusion = Mod.AppId.Value;
            settings.FixedRegion = Mod.Region.Value;
            string userId = System.Guid.NewGuid().ToString("N");
            args.CustomPhotonAppSettings = settings;
            args.AuthValues = new AuthenticationValues(userId) { AuthType = CustomAuthenticationType.None };
            args.PlayerCount = new Il2CppSystem.Nullable<int>(Mod.Slots);
            MelonLogger.Msg($"Starting {args.GameMode} room {args.SessionName} with {Mod.Slots} slots");
        }
    }

    [HarmonyPatch(typeof(AirlockPeer), nameof(AirlockPeer.PhotonAuth))]
    class SkipAuth
    {
        static void Prefix(ref bool requireAuthentication)
        {
            if (Mod.Enabled) requireAuthentication = false;
        }
    }

    [HarmonyPatch(typeof(AirlockPeer), nameof(AirlockPeer.WaitForCustomAuthenticationResponse))]
    class SkipAuthWait
    {
        static bool Prefix(ref Task __result)
        {
            if (!Mod.Enabled) return true;
            __result = Task.CompletedTask;
            return false;
        }
    }

    [HarmonyPatch(typeof(AirlockPeer), nameof(AirlockPeer.OnConnectFailed))]
    class LogConnectFailed
    {
        static void Prefix(object[] __args)
        {
            object reason = __args[2];
            MelonLogger.Warning($"Connect failed: {reason}");
        }
    }

    [HarmonyPatch(typeof(AirlockPeer), nameof(AirlockPeer.OnShutdown))]
    class LogShutdown
    {
        static void Prefix(ShutdownReason shutdownReason) => MelonLogger.Msg($"Left room: {shutdownReason}");
    }

    [HarmonyPatch(typeof(CloudServices), nameof(CloudServices.OnDisconnected))]
    class LogDisconnect
    {
        static void Prefix(DisconnectCause cause)
        {
            if (cause != DisconnectCause.DisconnectByClientLogic) MelonLogger.Warning($"Photon disconnected: {cause}");
        }
    }
}
