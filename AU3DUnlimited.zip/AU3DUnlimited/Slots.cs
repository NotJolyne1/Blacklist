using System.Collections.Generic;
using System.Text.RegularExpressions;
using HarmonyLib;
using Il2CppFusion;
using Il2CppInterop.Runtime;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Il2CppSG.Airlock;
using Il2CppSG.Airlock.Network;
using MelonLoader;
using UnityEngine;
using UnityEngine.SceneManagement;
using BindingFlags = Il2CppSystem.Reflection.BindingFlags;

namespace AU3DUnlimited
{
    [HarmonyPatch(typeof(NetworkSceneManagerBase), nameof(NetworkSceneManagerBase.FindNetworkObjects))]
    class AddSlots
    {
        public static readonly Dictionary<int, GameObject[]> Copies = new();
        public static readonly List<NetworkObject> Added = new();

        static void Postfix(Scene scene, Il2CppSystem.Collections.Generic.List<NetworkObject> __result)
        {
            int slotCount = Mod.Slots;
            if (!Mod.Enabled || __result == null) return;
            var spawnManager = FindSpawnManager(scene);
            if (spawnManager == null) return;
            int existing = spawnManager._playerStates.Count;
            if (existing == 0 || existing >= slotCount) return;

            var resultPositions = new Dictionary<int, int>();
            for (int position = 0; position < __result.Count; position++) resultPositions[__result[position].GetInstanceID()] = position;
            var nestedParents = FindNestedParents(scene);
            var extraNested = new Dictionary<NetworkObject, List<NetworkObject>>();
            var newRoots = new List<NetworkObject>();
            int insertAfter = -1;
            int ownObjectCount = 0;
            Copies.Clear();
            Added.Clear();

            for (int slot = existing; slot < slotCount; slot++)
            {
                int source = slot % existing;

                void TrackOwnObject(NetworkObject ownObject, NetworkObject owner)
                {
                    ownObjectCount++;
                    if (resultPositions.TryGetValue(owner.GetInstanceID(), out var ownerPosition)) insertAfter = Mathf.Max(insertAfter, ownerPosition);
                    newRoots.Add(ownObject);
                    Added.Add(ownObject);
                }

                void TrackClone(NetworkObject original, NetworkObject clone, GameObject originalRoot, int objectIndex)
                {
                    var guid = clone.NetworkGuid;
                    guid._data0 ^= unchecked((long)(0x9E3779B97F4A7C15UL * (ulong)(slot + 1)));
                    guid._data1 ^= unchecked((long)(0xC2B2AE3D27D4EB4FUL * (ulong)(slot + 1)) + objectIndex);
                    clone.NetworkGuid = guid;
                    Added.Add(clone);
                    bool isResultObject = resultPositions.TryGetValue(original.GetInstanceID(), out var objectPosition);
                    if (isResultObject) insertAfter = Mathf.Max(insertAfter, objectPosition);
                    if (isResultObject) newRoots.Add(clone);
                    if (!isResultObject) AddExtraNested(extraNested, nestedParents, original, clone, originalRoot);
                }

                Component Copy(Component component)
                {
                    if (component == null) return null;
                    var nextState = spawnManager._playerStates[(source + 1) % existing];
                    var originalRoot = TopOf(component, spawnManager, nextState).gameObject;
                    if (!Copies.TryGetValue(originalRoot.GetInstanceID(), out var copies)) Copies[originalRoot.GetInstanceID()] = copies = new GameObject[slotCount];
                    if (copies[slot] != null) return Find(component.transform, slot)?.GetComponent(component.GetIl2CppType());
                    var cloneRoot = copies[slot] = Object.Instantiate(originalRoot, originalRoot.transform.parent);
                    cloneRoot.name = Rename(originalRoot.name, source, slot);
                    var originalObjects = originalRoot.GetComponentsInChildren<NetworkObject>(true);
                    var cloneObjects = cloneRoot.GetComponentsInChildren<NetworkObject>(true);
                    var ownObject = GiveOwnObject(originalRoot, cloneRoot, slot, ownObjectCount, out var owner);
                    if (ownObject != null) TrackOwnObject(ownObject, owner);
                    for (int objectIndex = 0; objectIndex < originalObjects.Length && objectIndex < cloneObjects.Length; objectIndex++) TrackClone(originalObjects[objectIndex], cloneObjects[objectIndex], originalRoot, objectIndex);
                    return Find(component.transform, slot)?.GetComponent(component.GetIl2CppType());
                }

                var playerState = Copy(spawnManager._playerStates[source])?.TryCast<PlayerState>();
                if (playerState == null) { MelonLogger.Error($"Could not copy player slot {slot}"); return; }
                playerState._playerId = slot;
                spawnManager._playerStates.Add(playerState);
                if (spawnManager._backupPlayerStates.Count == slot) spawnManager._backupPlayerStates.Add(CopyBackup(Copy(spawnManager._backupPlayerStates[source]), slot));
                if (spawnManager._playerAvatars.Count == slot) spawnManager._playerAvatars.Add(Copy(spawnManager._playerAvatars[source])?.TryCast<NetworkedLocomotionPlayer>());
                if (spawnManager._networkedBodies.Count == slot) spawnManager._networkedBodies.Add(Copy(spawnManager._networkedBodies[source])?.TryCast<NetworkedBody>());
                if (spawnManager._spawnOutFX.Count == slot) spawnManager._spawnOutFX.Add(Copy(spawnManager._spawnOutFX[source])?.TryCast<ParticleSystem>());
            }

            foreach (var copies in Copies.Values)
            {
                for (int slot = existing; slot < slotCount; slot++)
                {
                    if (copies[slot] == null) continue;
                    foreach (var behaviour in copies[slot].GetComponentsInChildren<MonoBehaviour>(true)) Relink(behaviour, slot % existing, slot);
                }
            }

            int insertPosition = insertAfter + 1;
            foreach (var networkObject in newRoots) __result.Insert(insertPosition++, networkObject);
            foreach (var pair in extraNested) pair.Key.NestedObjects = Grow(pair.Key.NestedObjects, pair.Value);

            MelonLogger.Msg($"Player slots grew from {existing} to {spawnManager._playerStates.Count}, added {Added.Count} network objects");
        }

        static SpawnManager FindSpawnManager(Scene scene)
        {
            foreach (var root in scene.GetRootGameObjects())
            {
                var spawnManager = root.GetComponentInChildren<SpawnManager>(true);
                if (spawnManager != null) return spawnManager;
            }
            return null;
        }

        static Dictionary<int, NetworkObject> FindNestedParents(Scene scene)
        {
            var nestedParents = new Dictionary<int, NetworkObject>();
            foreach (var root in scene.GetRootGameObjects())
            {
                foreach (var networkObject in root.GetComponentsInChildren<NetworkObject>(true))
                {
                    if (networkObject.NestedObjects == null) continue;
                    foreach (var nested in networkObject.NestedObjects)
                    {
                        if (nested != null) nestedParents[nested.GetInstanceID()] = networkObject;
                    }
                }
            }
            return nestedParents;
        }

        static void AddExtraNested(Dictionary<NetworkObject, List<NetworkObject>> extraNested, Dictionary<int, NetworkObject> nestedParents, NetworkObject original, NetworkObject clone, GameObject originalRoot)
        {
            if (!nestedParents.TryGetValue(original.GetInstanceID(), out var parent)) return;
            if (parent.transform.IsChildOf(originalRoot.transform)) return;
            if (!extraNested.ContainsKey(parent)) extraNested[parent] = new List<NetworkObject>();
            extraNested[parent].Add(clone);
        }

        static PlayerState CopyBackup(Component backupCopy, int slot)
        {
            var backup = backupCopy?.TryCast<PlayerState>();
            if (backup != null) backup._playerId = slot;
            return backup;
        }

        static Transform TopOf(Component component, SpawnManager spawnManager, PlayerState nextState)
        {
            var networkObject = component.GetComponentInParent<NetworkObject>(true);
            if (networkObject == null || spawnManager.transform.IsChildOf(networkObject.transform)) return component.transform;
            var top = networkObject.transform;
            while (top.parent != null)
            {
                var parentObject = top.parent.GetComponentInParent<NetworkObject>(true);
                if (parentObject == null) break;
                if (spawnManager.transform.IsChildOf(parentObject.transform) || nextState.transform.IsChildOf(parentObject.transform)) break;
                top = parentObject.transform;
            }
            return top;
        }

        static NetworkObject GiveOwnObject(GameObject original, GameObject clone, int slot, int ownObjectCount, out NetworkObject owner)
        {
            var originalBehaviours = original.GetComponentsInChildren<NetworkBehaviour>(true);
            var cloneBehaviours = clone.GetComponentsInChildren<NetworkBehaviour>(true);
            owner = null;
            var ownBehaviours = new List<NetworkBehaviour>();
            for (int index = 0; index < originalBehaviours.Length && index < cloneBehaviours.Length; index++)
            {
                var behaviourOwner = originalBehaviours[index].GetComponentInParent<NetworkObject>(true);
                if (behaviourOwner == null || behaviourOwner.transform.IsChildOf(original.transform)) continue;
                owner ??= behaviourOwner;
                ownBehaviours.Add(cloneBehaviours[index]);
            }
            if (owner == null) return null;

            var networkObject = clone.AddComponent<NetworkObject>();
            networkObject.Flags = owner.Flags;
            networkObject.ObjectInterest = owner.ObjectInterest;
            networkObject.DefaultInterestGroups = owner.DefaultInterestGroups;
            networkObject.DestroyWhenStateAuthorityLeaves = owner.DestroyWhenStateAuthorityLeaves;
            networkObject.AllowStateAuthorityOverride = owner.AllowStateAuthorityOverride;
            var guid = owner.NetworkGuid;
            guid._data0 ^= unchecked((long)(0xD6E8FEB86659FD93UL * (ulong)(slot + 1)));
            guid._data1 ^= 0x5A5A0000L + ownObjectCount;
            networkObject.NetworkGuid = guid;
            networkObject.NetworkedBehaviours = Grow(new Il2CppReferenceArray<NetworkBehaviour>(0), ownBehaviours);
            networkObject.NestedObjects = new Il2CppReferenceArray<NetworkObject>(0);
            networkObject.SimulationBehaviours = new Il2CppReferenceArray<SimulationBehaviour>(0);
            return networkObject;
        }

        static Il2CppReferenceArray<T> Grow<T>(Il2CppReferenceArray<T> existing, List<T> extra) where T : Il2CppSystem.Object
        {
            var grown = new Il2CppReferenceArray<T>(existing.Length + extra.Count);
            for (int index = 0; index < existing.Length; index++) grown[index] = existing[index];
            for (int index = 0; index < extra.Count; index++) grown[existing.Length + index] = extra[index];
            return grown;
        }

        static void Relink(MonoBehaviour behaviour, int source, int slot)
        {
            var minigamePlayer = behaviour.TryCast<MinigamePlayer>();
            if (minigamePlayer != null && minigamePlayer.PlayerID == source) minigamePlayer.PlayerID = slot;
            var unityObjectType = Il2CppType.Of<Object>();
            var flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.DeclaredOnly;
            var type = behaviour.GetIl2CppType();
            while (type != null)
            {
                string typeNamespace = type.Namespace ?? "";
                if (!typeNamespace.StartsWith("SG")) break;
                foreach (var field in type.GetFields(flags))
                {
                    if (field.FieldType.IsValueType || !unityObjectType.IsAssignableFrom(field.FieldType)) continue;
                    var value = field.GetValue(behaviour)?.TryCast<Object>();
                    if (value == null) continue;
                    var gameObject = value.TryCast<GameObject>();
                    var fieldTransform = gameObject != null ? gameObject.transform : value.TryCast<Component>()?.transform;
                    if (fieldTransform == null) continue;
                    var match = Find(fieldTransform, slot);
                    if (match == null) continue;
                    field.SetValue(behaviour, Counterpart(value, match));
                }
                type = type.BaseType;
            }
        }

        public static Il2CppSystem.Object Counterpart(Object original, Transform match)
        {
            if (original.TryCast<GameObject>() != null) return match.gameObject;
            return match.GetComponent(original.GetIl2CppType());
        }

        public static string Rename(string name, int sourceSlot, int slot)
        {
            name = name.Replace("(Clone)", "").TrimEnd();
            var number = Regex.Match(name, @"\d+(?!.*\d)");
            if (number.Success && number.Value == sourceSlot.ToString()) return name.Remove(number.Index, number.Length).Insert(number.Index, slot.ToString());
            return $"{name} ({slot})";
        }

        public static Transform Find(Transform transform, int slot)
        {
            var path = new List<string>();
            for (var current = transform; current != null; current = current.parent)
            {
                bool hasCopy = Copies.TryGetValue(current.gameObject.GetInstanceID(), out var copies) && slot < copies.Length && copies[slot] != null;
                if (hasCopy) return FindInside(copies[slot], path);
                path.Insert(0, current.name);
            }
            return null;
        }

        static Transform FindInside(GameObject copy, List<string> path)
        {
            if (path.Count == 0) return copy.transform;
            return copy.transform.Find(string.Join("/", path));
        }
    }

    [HarmonyPatch(typeof(SpawnManager), nameof(SpawnManager.Spawned))]
    class GrowLists
    {
        static readonly HashSet<string> perPlayerFields = new()
        {
            "HandMeshCombiner._crewmateAvatars", "HandMeshCombiner._ghostAvatars",
            "PlayerSnapshot._textures", "PlayerSnapshot._materials",
            "UIMinimap.PlayerIndicators", "Holomap3D._crewmates", "Holomap3D._crewmateRoomLocation",
            "HolomapFlat._playerPositions", "QuickChatDrawer._playerNames",
            "VotingMainUI._voteIconsPool", "VotingPlayerUI._votedPlayers",
            "CutsceneSetupEndGame._crewmates", "CutsceneSetupEndGame._crewmatesAnimators", "CutsceneSetupEndGame._avatarCosmetics",
            "CutsceneSetupRoleReveal._crewmates", "CutsceneSetupRoleReveal._avatarCosmetics",
            "ModerationManager._playerIdToVoteOff", "PingManager._globalPingVariables",
            "InfectionMode._isInfectedStored", "TaskData.runtimeActiveSequenceIndex"
        };

        static void Postfix(SpawnManager __instance)
        {
            int slotCount = Mod.Slots;
            if (!Mod.Enabled || slotCount <= 10) return;
            var flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            var targets = FindTargets();
            int grown = 0;
            foreach (var target in targets)
            {
                foreach (var field in target.GetIl2CppType().GetFields(flags))
                {
                    string fieldName = $"{field.DeclaringType.Name}.{field.Name}";
                    if (!perPlayerFields.Contains(fieldName)) continue;
                    var fieldType = field.FieldType;
                    var fieldValue = field.GetValue(target);
                    if (fieldValue == null) continue;
                    try
                    {
                        if (fieldType.IsArray) grown += GrowArray(target, field, fieldValue, slotCount);
                        if (!fieldType.IsArray) grown += GrowList(fieldType, fieldValue, slotCount);
                    }
                    catch (System.Exception error)
                    {
                        MelonLogger.Warning($"Could not grow {fieldName}: {error.Message}");
                    }
                }
            }
            FixSelfies(__instance.PlayerSnapshot);
            MelonLogger.Msg($"Resized {grown} player lists to {slotCount}");
        }

        static List<Object> FindTargets()
        {
            var targets = new List<Object>();
            foreach (var asset in Object.FindObjectsOfTypeAll(Il2CppType.Of<ScriptableObject>()))
            {
                string typeNamespace = asset.GetIl2CppType().Namespace ?? "";
                if (typeNamespace.StartsWith("SG")) targets.Add(asset);
            }
            foreach (var behaviour in Object.FindObjectsOfType(Il2CppType.Of<MonoBehaviour>(), true)) targets.Add(behaviour);
            return targets;
        }

        static int GrowArray(Object target, Il2CppSystem.Reflection.FieldInfo field, Il2CppSystem.Object fieldValue, int slotCount)
        {
            var source = fieldValue.Cast<Il2CppSystem.Array>();
            int length = source.Length;
            if (length != 10) return 0;
            var bigger = Il2CppSystem.Array.CreateInstance(field.FieldType.GetElementType(), slotCount);
            for (int slot = 0; slot < slotCount; slot++)
            {
                var element = source.GetValue(slot % length);
                if (slot >= length) element = Duplicate(element, slot);
                bigger.SetValue(element, slot);
            }
            field.SetValue(target, bigger);
            return 1;
        }

        static int GrowList(Il2CppSystem.Type fieldType, Il2CppSystem.Object fieldValue, int slotCount)
        {
            var list = fieldValue.Cast<Il2CppSystem.Collections.IList>();
            int count = fieldType.GetProperty("Count").GetValue(fieldValue).Unbox<int>();
            if (count != 10) return 0;
            for (int slot = count; slot < slotCount; slot++) list.Add(Duplicate(list[slot % count], slot));
            return 1;
        }

        static void FixSelfies(PlayerSnapshot snapshot)
        {
            if (snapshot == null || snapshot._textures.Count < Mod.Slots || snapshot._materials.Count < Mod.Slots) return;
            for (int slot = 10; slot < Mod.Slots; slot++)
            {
                var material = snapshot._materials[slot];
                var oldTexture = snapshot._textures[slot % 10];
                foreach (int propertyId in material.GetTexturePropertyNameIDs())
                {
                    if (material.GetTexture(propertyId) != oldTexture) continue;
                    material.SetTexture(propertyId, snapshot._textures[slot]);
                }
            }
        }

        static Il2CppSystem.Object Duplicate(Il2CppSystem.Object element, int slot)
        {
            var unityObject = element?.TryCast<Object>();
            if (unityObject == null) return element;
            var gameObject = unityObject.TryCast<GameObject>();
            var component = unityObject.TryCast<Component>();
            var transform = gameObject != null ? gameObject.transform : component?.transform;
            if (transform == null) return CopyAsset(element, unityObject, slot);
            var match = AddSlots.Find(transform, slot);
            if (match != null) return AddSlots.Counterpart(unityObject, match);
            bool hasNetworkChild = transform.GetComponentInChildren<NetworkObject>(true) != null;
            bool hasNetworkParent = transform.GetComponentInParent<NetworkObject>(true) != null;
            bool hasBehaviour = transform.GetComponentInChildren<NetworkBehaviour>(true) != null;
            if (hasNetworkChild || (hasNetworkParent && hasBehaviour)) return element;
            var clone = Object.Instantiate(transform.gameObject, transform.parent);
            clone.name = AddSlots.Rename(transform.name, slot % 10, slot);
            return AddSlots.Counterpart(unityObject, clone.transform);
        }

        static Il2CppSystem.Object CopyAsset(Il2CppSystem.Object element, Object asset, int slot)
        {
            bool copyable = asset.TryCast<Material>() != null || asset.TryCast<RenderTexture>() != null;
            if (!copyable) return element;
            var copy = Object.Instantiate(asset);
            copy.name = AddSlots.Rename(asset.name, slot % 10, slot);
            return copy;
        }
    }

    [HarmonyPatch(typeof(SpawnManager), nameof(SpawnManager.GetTeleportTransform), new[] { typeof(int), typeof(TeleportTypes) })]
    class WrapSpawnPoints
    {
        static void Prefix(SpawnManager __instance, ref int player, TeleportTypes teleportType)
        {
            if (player < 10) return;
            foreach (var points in __instance.teleportTypePoints)
            {
                if (points.teleportType != teleportType || points.spawnPoints.Length == 0) continue;
                player %= points.spawnPoints.Length;
                return;
            }
        }
    }

    [HarmonyPatch(typeof(SpawnManager), nameof(SpawnManager.ActivePlayerStates), MethodType.Getter)]
    class OnlySpawnedStates
    {
        static bool Prefix(SpawnManager __instance, ref Il2CppSystem.Collections.Generic.List<PlayerState> __result)
        {
            if (!Mod.Enabled) return true;
            __result = new Il2CppSystem.Collections.Generic.List<PlayerState>();
            foreach (var state in __instance._playerStates)
            {
                if (PlayerChecks.IsConnected(state)) __result.Add(state);
            }
            return false;
        }
    }
}
