using System.Collections.Generic;
using HarmonyLib;
using Il2CppFusion;
using Il2CppInterop.Runtime.InteropTypes.Arrays;
using Il2CppSG.Airlock;
using Il2CppSG.Airlock.Customization;
using Il2CppSG.Airlock.Error;
using Il2CppSG.Airlock.Network;
using Il2CppSG.Airlock.UI;
using Il2CppSG.Airlock.UI.Moderation;
using MelonLoader;
using UnityEngine;

namespace AU3DUnlimited
{
    [HarmonyPatch(typeof(CrashMonitor), nameof(CrashMonitor.HandleCrash))]
    class KeepRoomOnError
    {
        static bool Prefix(string condition)
        {
            if (!Mod.Enabled) return true;
            string firstLine = condition?.Split('\n')[0];
            MelonLogger.Warning($"Kept the room open after an error: {firstLine}");
            return false;
        }
    }

    [HarmonyPatch]
    class IgnoreKnownErrors
    {
        static readonly HashSet<string> reported = new();

        static IEnumerable<System.Reflection.MethodBase> TargetMethods()
        {
            yield return AccessTools.Method(typeof(UILobbyScreenUI), nameof(UILobbyScreenUI.GetPlayerCount));
            yield return AccessTools.Method(typeof(GameplayMode), nameof(GameplayMode.ResetSheriffVisuals));
            yield return AccessTools.Method(typeof(QuickChatData), nameof(QuickChatData.SetCurrentPlayers));
        }

        static System.Exception Finalizer(System.Exception __exception, System.Reflection.MethodBase __originalMethod)
        {
            if (__exception == null || !Mod.Enabled) return __exception;
            string methodName = __originalMethod.Name;
            string typeName = __originalMethod.DeclaringType.Name;
            string message = __exception.Message.Split('\n')[0];
            if (reported.Add(methodName)) MelonLogger.Warning($"Ignored error in {typeName}.{methodName}: {message}");
            return null;
        }
    }

    [HarmonyPatch(typeof(QuickChatDrawer), nameof(QuickChatDrawer.PlayerColors), MethodType.Setter)]
    class QuickChatColors
    {
        static void Prefix(ref Il2CppStructArray<int> value)
        {
            if (!Mod.Enabled || value == null || value.Length >= Mod.Slots) return;
            var bigger = new Il2CppStructArray<int>(Mod.Slots);
            for (int index = 0; index < value.Length; index++) bigger[index] = value[index];
            value = bigger;
        }
    }

    [HarmonyPatch(typeof(QuickChatData), nameof(QuickChatData.MakePlayerPhrases))]
    class QuickChatNames
    {
        static void Prefix(ref Il2CppStringArray names)
        {
            if (!Mod.Enabled || names == null || names.Length == 0 || names.Length >= Mod.Slots) return;
            var bigger = new Il2CppStringArray(Mod.Slots);
            for (int index = 0; index < Mod.Slots; index++) bigger[index] = names[index % names.Length];
            names = bigger;
        }
    }

    [HarmonyPatch(typeof(SpawnManager), nameof(SpawnManager.OnPlayerJoined))]
    class NoSpectatorsInLobby
    {
        static void Postfix(SpawnManager __instance, NetworkRunner runner, PlayerRef player)
        {
            if (!Mod.Enabled || runner == null || !runner.IsServer) return;
            var session = Object.FindObjectOfType<GameSession>();
            if (session == null || !session.Object.IsValid || session.GameInProgress) return;
            int playerId = player.PlayerId;
            if (playerId < 0 || playerId >= __instance._playerStates.Count) return;
            var state = __instance._playerStates[playerId];
            if (PlayerChecks.IsLive(state) && state.IsSpectating) state.IsSpectating = false;
        }
    }

    [HarmonyPatch(typeof(ScreenSpaceHUD), nameof(ScreenSpaceHUD.SetSelfPortrait))]
    class OwnPortrait
    {
        static void Prefix([HarmonyArgument("t")] ref Texture portrait)
        {
            if (!Mod.Enabled) return;
            var spawnManager = Object.FindObjectOfType<SpawnManager>();
            var local = spawnManager?.GetLocalPlayerState();
            var snapshot = spawnManager?.PlayerSnapshot;
            if (local == null || snapshot == null || local._playerId < 0 || local._playerId >= snapshot._textures.Count) return;
            portrait = snapshot._textures[local._playerId];
        }
    }

    [HarmonyPatch(typeof(VotingPlayerUI), nameof(VotingPlayerUI.SetPlayer))]
    class BoardNames
    {
        static void Prefix(VotingPlayerUI __instance, ref int playerNameIndex)
        {
            if (!Mod.Enabled) return;
            int playerId = __instance._playerId.PlayerId;
            if (playerId >= 0 && playerId < Mod.Slots) playerNameIndex = playerId;
        }
    }

    class LayoutSizes
    {
        public float Width;
        public float Height;
        public float Padding;
        public float VerticalPadding;
        public int Columns;
        public Vector3 ChildScale;
    }

    [HarmonyPatch(typeof(UILayout), nameof(UILayout.Layout))]
    class FitBoard
    {
        static readonly Dictionary<int, LayoutSizes> originals = new();

        static void Prefix(UILayout __instance)
        {
            if (!__instance.name.StartsWith("VotingPlayerLayout")) return;
            var layoutTransform = __instance.transform;
            int key = __instance.GetInstanceID();
            if (!originals.ContainsKey(key) && layoutTransform.childCount == 0) return;
            if (!originals.ContainsKey(key)) originals[key] = ReadSizes(__instance);
            var original = originals[key];
            int activeCount = 0;
            for (int index = 0; index < layoutTransform.childCount; index++)
            {
                if (layoutTransform.GetChild(index).gameObject.activeSelf) activeCount++;
            }
            int columns = original.Columns;
            if (Mod.Enabled && activeCount > original.Columns * 4) columns = original.Columns + 1;
            float shrink = columns == original.Columns ? 1f : ShrinkFactor(original, columns, activeCount);
            __instance.ChildWidth = original.Width * shrink;
            __instance.ChildHeight = original.Height * shrink;
            __instance.Padding = original.Padding * shrink;
            __instance.VertPadding = original.VerticalPadding * shrink;
            __instance.MaxGridSize = columns;
            for (int index = 0; index < layoutTransform.childCount; index++) layoutTransform.GetChild(index).localScale = original.ChildScale * shrink;
        }

        static LayoutSizes ReadSizes(UILayout layout)
        {
            var sizes = new LayoutSizes();
            sizes.Width = layout.ChildWidth;
            sizes.Height = layout.ChildHeight;
            sizes.Padding = layout.Padding;
            sizes.VerticalPadding = layout.VertPadding;
            sizes.Columns = layout.MaxGridSize;
            sizes.ChildScale = layout.transform.GetChild(0).localScale;
            return sizes;
        }

        static float ShrinkFactor(LayoutSizes original, int columns, int activeCount)
        {
            int rows = (activeCount + columns - 1) / columns;
            float fitWide = (original.Columns * original.Width + (original.Columns - 1) * original.Padding) / (columns * original.Width + (columns - 1) * original.Padding);
            float fitTall = (4 * original.Height + 3 * original.VerticalPadding) / (rows * original.Height + (rows - 1) * original.VerticalPadding);
            return Mathf.Min(fitWide, fitTall);
        }
    }

    [HarmonyPatch(typeof(Moderation), "Start")]
    class TabForEveryone
    {
        static void Prefix(Moderation __instance)
        {
            if (!Mod.Enabled) return;
            var tabs = __instance.GetComponentsInChildren<ModerationPlayerTab>(true);
            if (tabs.Length == 0 || tabs.Length >= Mod.Slots) return;
            var existingIds = new HashSet<int>();
            foreach (var tab in tabs) existingIds.Add(tab._playerId);
            var template = tabs[0].gameObject;
            for (int playerId = 0; playerId < Mod.Slots; playerId++)
            {
                if (existingIds.Contains(playerId)) continue;
                var copy = Object.Instantiate(template, template.transform.parent);
                copy.name = $"UI_Moderation_PlayerPanel ({playerId + 1})";
                copy.GetComponent<ModerationPlayerTab>()._playerId = playerId;
            }
        }
    }

    [HarmonyPatch(typeof(Moderation), "Update")]
    class TabGrid
    {
        static readonly Dictionary<int, (Vector3 origin, Vector3 across, Vector3 down, Vector3 scale)> grids = new();

        static void Postfix(Moderation __instance)
        {
            var tabs = __instance._moderationPlayers;
            if (!Mod.Enabled || tabs == null || tabs.Length <= 10) return;
            int key = __instance.GetInstanceID();
            if (!grids.ContainsKey(key) && !BuildGrid(__instance, key)) return;
            var grid = grids[key];
            var shown = new List<ModerationPlayerTab>();
            foreach (var tab in tabs) if (tab.gameObject.activeSelf) shown.Add(tab);
            shown.Sort((first, second) => Order(first._playerId).CompareTo(Order(second._playerId)));
            bool compact = shown.Count > 10;
            int rows = compact ? (shown.Count + 2) / 3 : 5;
            float factor = compact ? 2f / 3f : 1f;
            for (int position = 0; position < shown.Count; position++)
            {
                int column = position / rows;
                int row = position % rows;
                var tabTransform = shown[position].transform;
                tabTransform.localPosition = grid.origin + grid.across * (factor * column) + grid.down * (factor * row);
                tabTransform.localScale = grid.scale * factor;
            }
        }

        static bool BuildGrid(Moderation moderation, int key)
        {
            Transform top = null;
            Transform below = null;
            Transform right = null;
            foreach (var tab in moderation._moderationPlayers)
            {
                if (tab._playerId == 9) top = tab.transform;
                if (tab._playerId == 0) below = tab.transform;
                if (tab._playerId == 4) right = tab.transform;
            }
            if (top == null || below == null || right == null) return false;
            grids[key] = (top.localPosition, right.localPosition - top.localPosition, below.localPosition - top.localPosition, top.localScale);
            return true;
        }

        static int Order(int playerId) => playerId == Mod.Slots - 1 ? -1 : playerId;
    }

    [HarmonyPatch(typeof(GameSession), nameof(GameSession.MaxPlayers), MethodType.Getter)]
    class ShowMaxPlayers
    {
        static void Postfix(ref int __result)
        {
            if (Mod.Enabled && __result > 0 && __result < Mod.Slots) __result = Mod.Slots;
        }
    }

    [HarmonyPatch(typeof(CustomizationManager), nameof(CustomizationManager.IsColorTaken))]
    class ColorNeverTaken
    {
        static bool Prefix(ref bool __result)
        {
            if (!Mod.Enabled) return true;
            __result = false;
            return false;
        }
    }

    [HarmonyPatch(typeof(CustomizationManager), nameof(CustomizationManager.DisableExistingColorButtons))]
    class KeepColorButtons
    {
        static bool Prefix() => !Mod.Enabled;
    }

    [HarmonyPatch(typeof(PlayerState), nameof(PlayerState.RPC_ForceCheckColor))]
    class NoColorBounce
    {
        static bool Prefix() => !Mod.Enabled;
    }

    [HarmonyPatch(typeof(CustomizationButton), nameof(CustomizationButton.OnInteractionStart))]
    class ClickAnyColor
    {
        static void Prefix(CustomizationButton __instance)
        {
            var element = __instance._element;
            if (!Mod.Enabled || element == null || !element.IsLocked || element.Type != CustomizationElement.CosmeticType.Color) return;
            var customization = __instance._customizationManager;
            if (customization == null) return;
            int elementIndex = customization.FindElementIndex(element);
            if (customization.IsEntitled(elementIndex)) element.IsLocked = false;
        }
    }

    [HarmonyPatch(typeof(CustomizationManager), nameof(CustomizationManager.ApplyElementNetworked))]
    class HostAppliesColor
    {
        static void Postfix(CustomizationManager __instance, int elementIndex, int playerIndex)
        {
            if (!Mod.Enabled || __instance.Runner == null || !__instance.Runner.IsServer) return;
            var elements = __instance._elementCollection?.AllCustomizationElements;
            if (elements == null || elementIndex < 0 || elementIndex >= elements.Count) return;
            if (elements[elementIndex].Type != CustomizationElement.CosmeticType.Color) return;
            var spawnManager = Object.FindObjectOfType<SpawnManager>();
            if (spawnManager == null || playerIndex < 0 || playerIndex >= spawnManager._playerStates.Count) return;
            var state = spawnManager._playerStates[playerIndex];
            if (PlayerChecks.IsLive(state) && state.ColorId != elementIndex) state.UpdateColorID(elementIndex);
        }
    }
}
